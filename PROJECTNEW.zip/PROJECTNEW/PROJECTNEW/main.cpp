#include "mainwindow.h"

#include <QApplication>
#include <QMainWindow>
#include <QLabel>
#include <QPixmap>
#include <QIcon>

int main(int argc, char *argv[])
{


    QApplication a(argc, argv);
    MainWindow w;
    w.setWindowTitle("Ultimate Spell-checker");
    QPixmap background(":/image_123650291.JPG");

    QPixmap scaledBackground = background.scaled(w.size(), Qt::IgnoreAspectRatio);

    QPalette palette;
    palette.setBrush(QPalette::Window, scaledBackground);
    w.setPalette(palette);
    w.setFixedSize(w.size());

    QIcon icon(":/image_123650291 (2).JPG");
    w.setWindowIcon(icon);

    w.show();

    return a.exec();
}
